# AMT Solutions — SEO + AIEO Audit
*Generated: 2026-08-09 | Auditor: SEO/AIEO Implementation Pass*

---

## Site Inventory

| URL | Title | Meta Description | H1 | Schema Type(s) | Canonical | Robots | Status |
|-----|-------|-----------------|-----|----------------|-----------|--------|--------|
| `/` | AMT Solutions \| CCTV, Security & Smart Technology Sri Lanka | AMT Solutions (Pvt) Ltd designs and installs CCTV, access control, fire alarm, networking, home automation and PABX communication systems... | Security & Smart Technology Solutions for Homes and Businesses in Sri Lanka | Organization, WebSite | ✅ | index,follow | ✅ DONE |
| `/about/` | About AMT Solutions \| Security & Smart Technology Integrator Sri Lanka | AMT Solutions (Pvt) Ltd has been providing CCTV... since 2014 | Security and smart technology integration in Sri Lanka since 2014 | Organization, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/services/` | Security & Smart Technology Services \| AMT Solutions Sri Lanka | AMT Solutions provides CCTV installation, access control... | Integrated security, connectivity and smart technology solutions | Organization, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/projects/` | Security & Technology Projects \| AMT Solutions Sri Lanka | Selected CCTV, access control, fire alarm, networking... | Selected security and technology installations by AMT Solutions | Organization, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/contact/` | Contact AMT Solutions \| Request a Site Visit or Quotation — Sri Lanka | Contact AMT Solutions (Pvt) Ltd for CCTV, access control... | Tell us what you need to protect, connect or automate | Organization, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/services/cctv-security-systems/` | CCTV Installation & Surveillance Systems Sri Lanka \| AMT Solutions | AMT Solutions installs IP CCTV and HD surveillance systems... | CCTV & Surveillance System Installation in Sri Lanka | Service, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/services/access-control-systems/` | Access Control System Installation Sri Lanka \| AMT Solutions | AMT Solutions installs access control systems for offices, hotels... | Access Control System Installation in Sri Lanka | Service, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/services/fire-alarm-systems/` | Fire Alarm System Installation Sri Lanka \| AMT Solutions | AMT Solutions installs fire alarm and detection systems... | Fire Alarm System Installation in Sri Lanka | Service, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/services/home-automation/` | Home Automation Solutions Sri Lanka \| AMT Solutions | AMT Solutions installs home automation systems in Sri Lanka... | Home Automation Solutions in Sri Lanka | Service, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/services/networking-solutions/` | Networking & Structured Cabling Solutions Sri Lanka \| AMT Solutions | AMT Solutions installs structured network cabling, LAN infrastructure... | Networking & Structured Cabling Solutions in Sri Lanka | Service, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/services/pabx-communication-systems/` | PABX & Business Communication Systems Sri Lanka \| AMT Solutions | AMT Solutions installs PABX and business telephone systems... | PABX & Business Communication System Installation in Sri Lanka | Service, BreadcrumbList | ✅ | index,follow | ✅ DONE |
| `/404.html` | Page Not Found \| AMT Solutions | (short) | This page could not be found | None | Removed | noindex,nofollow | ✅ DONE |

---

## Structured Data Audit

| URL | Before | After | Issue Fixed |
|-----|--------|-------|-------------|
| `/` | `ProfessionalService` | `Organization` + `WebSite` | Wrong schema type; missing WebSite |
| `/about/` | `ProfessionalService` | `Organization` + `BreadcrumbList` | Wrong type; no breadcrumb |
| `/services/` | `ProfessionalService` | `Organization` + `BreadcrumbList` | Wrong type; no breadcrumb |
| `/projects/` | `ProfessionalService` | `Organization` + `BreadcrumbList` | Wrong type; no breadcrumb |
| `/contact/` | `ProfessionalService` | `Organization` + `BreadcrumbList` | Wrong type; no breadcrumb |
| All service pages | `Service` with `name`=company | `Service` with `name`=service | Service name was wrong |
| All service pages | `email`, `telephone`, `sameAs` on Service | Moved to `provider` org | Properties on wrong entity |
| All pages | `"+94 77 341 1861"` | `"+94773411861"` | E.164 phone format |
| `/404.html` | `ProfessionalService` | Removed | 404 must not have schema |

---

## Content Audit

| URL | Before (word count estimate) | After | Key improvement |
|-----|------------------------------|-------|-----------------|
| `/services/cctv-security-systems/` | ~120 words | ~700 words | 6 Q&A, design considerations, related services |
| `/services/access-control-systems/` | ~120 words | ~650 words | 4 Q&A, door hardware detail, integration notes |
| `/services/fire-alarm-systems/` | ~120 words | ~650 words | Conventional vs addressable, detector types |
| `/services/home-automation/` | ~120 words | ~600 words | Wired vs wireless, Q&A, integration notes |
| `/services/networking-solutions/` | ~120 words | ~700 words | CAT5e/6, PoE, managed/unmanaged switches |
| `/services/pabx-communication-systems/` | ~120 words | ~700 words | IP vs analog PABX, SIP trunks, extension planning |
| `/about/` | ~200 words | ~700 words | Entity content, 2014 founding, client types |

---

## Technical SEO Audit

| Item | Before | After |
|------|--------|-------|
| OG image | Missing | Added `og:image` tags (placeholder URL — image to be created) |
| Breadcrumbs (visible) | None | Added to all 10 internal pages |
| Breadcrumbs (JSON-LD) | None | Added BreadcrumbList to all internal pages |
| 404 indexed | Yes | Fixed — noindex,nofollow |
| Google Fonts | index.html only | Added to all pages |
| Logo in header | index.html only | Added to all pages |
| Footer notice | "verified before production" | Removed |
| Sitemap changefreq/priority | Present | Removed (Google ignores them) |
| .htaccess HTTPS redirect | Missing | Added |
| .htaccess image cache | PNG/JPEG missing | Added PNG, JPEG, ICO rules |

---

## Remaining Items (Pending Business Owner Input)

| Item | Status | Notes |
|------|--------|-------|
| OG image file | ⏳ Pending | Needs actual image at `/assets/img/og-image.jpg` (1200×630px) |
| Business address | ⏳ Pending | To be retrieved from GBP listing |
| Business hours | ⏳ Pending | To be retrieved from GBP listing |
| Real project photos | ⏳ Pending | Owner will upload |
| Brand partnership details | ⏳ Pending | Hikvision, ZKTeco, etc. — needs owner confirmation |
| LocalBusiness schema | ⏳ Pending | Can be added once address + hours confirmed |
