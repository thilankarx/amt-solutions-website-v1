# AMT Solutions — Structured Data Map
*Updated: 2026-08-09*

---

## Schema.org Implementation Overview

AMT Solutions uses JSON-LD blocks embedded in `<head>` for all structured data. No Microdata or RDFa is used.

---

## Page-by-Page Schema Map

### `/` — Homepage

```json
{
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://amtsolutions.lk/#organization",
      "name": "AMT Solutions (Pvt) Ltd",
      "url": "https://amtsolutions.lk",
      "logo": "https://amtsolutions.lk/assets/img/logo.png",
      "description": "...",
      "foundingDate": "2014",
      "email": "info@amtsolutions.lk",
      "telephone": "+94773411861",
      "areaServed": { "@type": "Country", "name": "Sri Lanka" },
      "sameAs": ["https://www.facebook.com/AMT.SolutionsGroup"],
      "hasOfferCatalog": { ... 6 services ... }
    },
    {
      "@type": "WebSite",
      "@id": "https://amtsolutions.lk/#website",
      "url": "https://amtsolutions.lk",
      "name": "AMT Solutions",
      "publisher": { "@id": "https://amtsolutions.lk/#organization" }
    }
  ]
}
```

**Purpose:** Establishes AMT Solutions as an entity with a canonical `@id`. The `WebSite` schema enables sitelinks eligibility. The `hasOfferCatalog` signals the service portfolio to Google and AI search engines.

---

### `/about/` — About Page

```json
{
  "@graph": [
    { "@type": "Organization", "@id": "...", "foundingDate": "2014", ... },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "position": 1, "name": "Home", "item": "https://amtsolutions.lk/" },
        { "position": 2, "name": "About", "item": "https://amtsolutions.lk/about/" }
      ]
    }
  ]
}
```

---

### `/contact/` — Contact Page

```json
{
  "@graph": [
    { "@type": "Organization", "@id": "...", "telephone": "+94773411861", ... },
    { "@type": "BreadcrumbList", ... }
  ]
}
```

> **Note:** Once the business address and hours are confirmed, upgrade to `LocalBusiness` with `address` (PostalAddress) and `openingHoursSpecification`.

---

### `/services/` — Services Hub

```json
{
  "@graph": [
    { "@type": "Organization", ... },
    { "@type": "BreadcrumbList", ... [Home → Services] }
  ]
}
```

---

### `/projects/` — Projects Page

```json
{
  "@graph": [
    { "@type": "Organization", ... },
    { "@type": "BreadcrumbList", ... [Home → Projects] }
  ]
}
```

> **Upgrade path:** Once real project data is available, individual projects can use `Project` or `CreativeWork` schema with client-approved details.

---

### Service Pages (all 6)

All service pages use the same pattern:

```json
{
  "@graph": [
    {
      "@type": "Service",
      "name": "[Service Name]",
      "description": "[Service-specific description]",
      "serviceType": "[Service category]",
      "areaServed": { "@type": "Country", "name": "Sri Lanka" },
      "provider": {
        "@type": "Organization",
        "@id": "https://amtsolutions.lk/#organization",
        "name": "AMT Solutions (Pvt) Ltd",
        "url": "https://amtsolutions.lk",
        "telephone": "+94773411861",
        "email": "info@amtsolutions.lk"
      },
      "url": "[Page URL]"
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "position": 1, "name": "Home", "item": "..." },
        { "position": 2, "name": "Services", "item": "..." },
        { "position": 3, "name": "[Service Name]", "item": "..." }
      ]
    }
  ]
}
```

#### Service-specific `name` and `serviceType` values:

| Page | `name` | `serviceType` |
|------|--------|---------------|
| CCTV | CCTV & Surveillance System Installation | CCTV Installation & Surveillance Systems |
| Access Control | Access Control System Installation | Access Control Systems |
| Fire Alarm | Fire Alarm System Installation | Fire Alarm Systems |
| Home Automation | Home Automation | Home Automation |
| Networking | Networking & Structured Cabling Solutions | Networking & Structured Cabling |
| PABX | PABX & Business Communication Systems | PABX & Communication Systems |

---

### `/404.html` — Error Page

**No structured data.** Page is set to `noindex,nofollow`. No schema block is appropriate for an error page.

---

## Validation

Validate all JSON-LD at: **https://validator.schema.org/**
Also check with Google Rich Results Test: **https://search.google.com/test/rich-results**

---

## Future Schema Opportunities (Pending Business Owner Data)

| Schema Type | Trigger | Required Data |
|-------------|---------|---------------|
| `LocalBusiness` | Once address and hours confirmed | Street address, postal code, opening hours |
| `FAQPage` | Optional enhancement to service pages | The Q&A content already exists — can wrap in FAQPage schema |
| `ImageObject` | Once project photos uploaded | Image URL, dimensions, description |
| `Review` / `AggregateRating` | If Google reviews are pulled | Stars, review count — **do not fabricate** |
