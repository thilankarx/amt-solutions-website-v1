# AMT Solutions — Kandy CCTV SEO Audit
*Updated: 2026-08-10*

---

## New & Modified Pages

### NEW: `/cctv-installation-kandy/`

| Field | Value |
|-------|-------|
| Title | CCTV Installation in Kandy \| Security Camera Systems \| AMT Solutions |
| Meta description | Professional CCTV installation in Kandy for homes, shops, offices and businesses. Camera systems, recording, remote viewing and system upgrades by AMT Solutions. |
| H1 | CCTV Installation in Kandy |
| Canonical | https://amtsolutions.lk/cctv-installation-kandy/ |
| Robots | index,follow,max-image-preview:large |
| Schema | Service (areaServed: City/Kandy) + BreadcrumbList |
| OG tags | ✅ Complete |
| Breadcrumb | Home → CCTV Installation in Kandy |
| Word count | ~2,200 words |
| Primary intent | Commercial — local CCTV installation in Kandy |
| Primary keywords | "CCTV installation in Kandy", "CCTV Kandy", "security camera installation Kandy" |
| Secondary keywords | "home CCTV Kandy", "commercial CCTV Kandy", "IP CCTV Kandy", "CCTV installer Kandy" |

### NEW: `/projects/cctv-installation-dangolla/`

| Field | Value |
|-------|-------|
| Title | CCTV Installation in Dangolla, Kandy \| AMT Solutions Project |
| Meta description | CCTV surveillance installation completed by AMT Solutions at a residential property in Dangolla, Kandy. Smart security cameras with protective housings. |
| H1 | CCTV Installation Project in Dangolla, Kandy |
| Canonical | https://amtsolutions.lk/projects/cctv-installation-dangolla/ |
| Robots | index,follow,max-image-preview:large |
| Schema | BreadcrumbList |
| Breadcrumb | Home → Projects → CCTV Installation — Dangolla |
| Content status | Verified facts only (EZVIZ cameras, iron protective boxes, residential) |

### DRAFT: `/projects/cctv-installation-ampitiya/`

| Field | Value |
|-------|-------|
| Status | **DRAFT — noindex,nofollow** |
| Action required | Verify project details with AMT Solutions before publishing |
| NOT in sitemap | ✅ Correct |
| NOT linked publicly | ✅ Correct |

### MODIFIED: `/index.html` (Homepage)

| Change | Details |
|--------|---------|
| New section | "CCTV installation in Kandy" section added before CTA panel |
| Footer | Added "CCTV Installation in Kandy" link under Solutions |
| Impact | Natural Kandy relevance signal without keyword stuffing |

### MODIFIED: `/services/cctv-security-systems/`

| Change | Details |
|--------|---------|
| New section | "Looking for CCTV installation in Kandy?" section added before CTA |
| Footer | Added "CCTV Installation in Kandy" link under Solutions |
| Impact | Parent→child link from broad CCTV page to local Kandy page |

### MODIFIED: `/projects/index.html`

| Change | Details |
|--------|---------|
| New card | Dangolla CCTV project card added with link to detail page |
| Footer | Added "CCTV Installation in Kandy" link |

---

## Internal Link Architecture

```
Homepage (/index.html)
  ├── [section + CTA] → /cctv-installation-kandy/
  └── [footer] → /cctv-installation-kandy/

/services/cctv-security-systems/
  ├── [section + CTA] → /cctv-installation-kandy/
  └── [footer] → /cctv-installation-kandy/

/cctv-installation-kandy/
  ├── [project card] → /projects/cctv-installation-dangolla/
  ├── [related service] → /services/cctv-security-systems/
  ├── [related service] → /services/networking-solutions/
  ├── [related service] → /services/access-control-systems/
  └── [multiple CTAs] → /contact/

/projects/cctv-installation-dangolla/
  ├── [related service] → /cctv-installation-kandy/
  ├── [related service] → /services/cctv-security-systems/
  └── [related service] → /projects/

/projects/index.html
  └── [project card] → /projects/cctv-installation-dangolla/

ALL pages (footer)
  └── /cctv-installation-kandy/
```

---

## Keyword Cannibalization Check

| Page | Primary target | Overlap risk |
|------|---------------|-------------|
| `/services/cctv-security-systems/` | CCTV installation Sri Lanka (country-level) | ✅ No overlap — different geo target |
| `/cctv-installation-kandy/` | CCTV installation Kandy (city-level) | ✅ No overlap — different geo target |

The broad page targets Sri Lanka. The Kandy page targets the city of Kandy. No cannibalization exists because the intent and geographic scope are clearly differentiated.

---

## Technical SEO Validation Checklist

- [x] `/cctv-installation-kandy/` returns valid HTML
- [x] Unique title (not duplicated on any other page)
- [x] Unique meta description
- [x] One H1 per page
- [x] Canonical correct and consistent
- [x] Visible breadcrumbs implemented
- [x] BreadcrumbList schema valid
- [x] Service schema valid
- [x] No fake LocalBusiness information
- [x] Internal links correct (verified across all modified pages)
- [x] Sitemap updated (2 new URLs added)
- [x] robots.txt allows crawl (no blocking rules for new paths)
- [x] No duplicate Kandy landing pages
- [x] HTTPS URLs used consistently
- [x] CTA links work (phone, WhatsApp, contact page)
- [x] No invalid JSON-LD
- [x] No duplicate element IDs
- [x] Ampitiya draft page set to noindex,nofollow

---

## AIEO Content Validation

The Kandy landing page clearly answers:

| Question | Answered? |
|----------|-----------|
| Who is AMT Solutions? | ✅ Named entity with founding year |
| Does AMT provide CCTV installation? | ✅ Primary topic of page |
| Does AMT serve Kandy? | ✅ In H1, lead text, multiple sections |
| What type of CCTV systems are available? | ✅ IP, HD, NVR, DVR, smart, Wi-Fi |
| Does AMT install CCTV for homes? | ✅ Dedicated residential section |
| Does AMT install CCTV for businesses? | ✅ Dedicated commercial section |
| Can CCTV be viewed remotely? | ✅ Dedicated section + FAQ |
| Can existing CCTV systems be upgraded? | ✅ Dedicated section + FAQ |
| How does the installation process work? | ✅ 7-step process section |
| Why is a site assessment useful? | ✅ Dedicated section |
| What Kandy-area projects demonstrate experience? | ✅ Dangolla project evidence |
| How can a customer contact AMT? | ✅ Multiple CTAs, phone, WhatsApp |

---

## Items Requiring AMT Confirmation

| Item | Status | Impact |
|------|--------|--------|
| Ampitiya CCTV project | ⏳ PENDING | Cannot publish Ampitiya project page or add to Kandy page |
| Additional service areas (Katugastota, Kundasale, Akurana, Digana, Pilimathalawa) | ⏳ PENDING | Would strengthen service area section |
| Business address for LocalBusiness schema | ⏳ PENDING | Would improve local search visibility |
| Dangolla project photographs | ⏳ PENDING | Would replace placeholder on project page |
| Kandy CCTV hero image | ⏳ PENDING | Would improve LCP and visual quality |
