# AMT Solutions — Local Citation Plan
*Updated: 2026-08-10*

---

## Purpose

Maintain consistent business information (NAP: Name, Address, Phone) across all online directories and platforms. Inconsistent citations confuse search engines and reduce local ranking signals.

---

## Official Business Information

| Field | Value | Status |
|-------|-------|--------|
| Business name | AMT Solutions (Pvt) Ltd | ✅ Confirmed |
| Phone 1 | +94 77 341 1861 | ✅ Confirmed |
| Phone 2 | +94 75 545 3676 | Found on Facebook/directories — confirm if official |
| Email | info@amtsolutions.lk | ✅ Confirmed |
| Website | https://amtsolutions.lk | ✅ Confirmed |
| Address | No. 306/B/1, Kandakaduwa, Gannoruwa, Peradeniya, Kandy | ⏳ PENDING BUSINESS CONFIRMATION |
| Facebook | https://www.facebook.com/AMT.SolutionsGroup | ✅ Confirmed |
| Founded | 2014 | ✅ Confirmed |

> **Action required**: Confirm the business address and whether it should be published publicly.

---

## Priority 1 — Essential Citations

These platforms have the highest impact on local search visibility in Sri Lanka:

| Platform | URL | Status | Action |
|----------|-----|--------|--------|
| Google Business Profile | https://share.google/eDY7que73AeGAyP3V | ✅ Listed | Verify ownership, update info |
| Facebook Business Page | https://www.facebook.com/AMT.SolutionsGroup | ✅ Listed | Ensure NAP matches website |
| Lanka Yellow Pages | lankayp.com | ✅ Listed | Verify and update listing |
| Jobzo.lk | jobzo.lk | ✅ Listed | Verify and update listing |

---

## Priority 2 — Recommended Citations

| Platform | Type | Action |
|----------|------|--------|
| Bing Places | Local business directory | Create listing with consistent NAP |
| Apple Business Connect | Local business directory | Create listing |
| Instagram Business | Social media | Create/link with consistent branding |
| LinkedIn Company Page | Professional directory | Create with company info |

---

## Priority 3 — Industry-Specific Citations

| Platform | Type | Notes |
|----------|------|-------|
| Sri Lanka Telecom Yellow Pages | Sri Lankan directory | Check for existing listing |
| Ceylon Pages | Sri Lankan directory | Submit if not listed |
| Lanka Business Online | Business directory | Check for listing opportunity |
| Supplier directories | Industry | If AMT is listed as a reseller/installer for any equipment brand |

---

## Citation Guidelines

### Do

- ✅ Use the exact business name format: **AMT Solutions (Pvt) Ltd**
- ✅ Use the same phone number format consistently
- ✅ Use the same website URL: **https://amtsolutions.lk**
- ✅ Use the same address format across all platforms
- ✅ Include services offered in directory descriptions
- ✅ Include the founding year (2014) where available

### Do Not

- ❌ Do NOT use abbreviated names like "AMT" or "AMT Solutions Group"
- ❌ Do NOT list different addresses on different platforms
- ❌ Do NOT submit to spam directories or link farms
- ❌ Do NOT pay for citations on low-quality directories
- ❌ Do NOT create duplicate listings on the same platform
- ❌ Do NOT claim brand authorizations that aren't verified (e.g., "Hikvision Authorized Dealer")

---

## Citation Audit Process

Review citations quarterly:

1. Search for "AMT Solutions" on Google, Bing, and local directories
2. Check that NAP is consistent on every listing found
3. Correct any inconsistencies
4. Claim any unclaimed listings
5. Remove any duplicate listings
6. Report any fake or fraudulent listings
